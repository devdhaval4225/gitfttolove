import React from 'react'
import Home from './components/pages/home'



const App = () => {
  return (
    <>
      <Home />
    </>
   
  )
}

export default App
