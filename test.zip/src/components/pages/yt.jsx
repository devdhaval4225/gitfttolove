import React from 'react'

const yt = () => {
  return (
    <div>
<iframe className='w-full h-175 max-w-7xl mx-auto' src="https://www.youtube.com/embed/uil0h2LqrpY" title="Miniature Fairy Garden" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


    </div>
  )
}

export default yt
